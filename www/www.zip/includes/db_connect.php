<?php
$db_host ="localhost";
$db_user ="u584287689_admin";
$db_pass ='rjvfhbr3010023';
$db_database ="u584287689_comp";
$link = mysql_connect($db_host, $db_user, $db_pass );
mysql_select_db($db_database,$link) or die("���� ��'���� � ��".mysql_error());
mysql_query("SET names cp1251");
?>