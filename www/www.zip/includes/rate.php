
<script type="text/javascript">

function calc() {

//var type_cms = document.getElementById("type_cms");

// var type_design = document.getElementById("type_design");

//var type_host = document.getElementById("type_host");

//var soprovozhdenie = document.getElementById("soprovozhdenie");

//var content = document.getElementById("content");

//var seo = document.getElementById("seo");

//var type_forum = document.getElementById("type_forum");

//var comment = document.getElementById("comment");
var point1 = document.getElementById("point1");
var point2 = document.getElementById("point2");
var point3 = document.getElementById("point3");
var point4 = document.getElementById("point4");
var point5 = document.getElementById("point5");
var point6 = document.getElementById("point6");
var point7 = document.getElementById("point7");
var point8 = document.getElementById("point8");
var point9 = document.getElementById("point9");
var point10 = document.getElementById("point10");
var point11 = document.getElementById("point11");
var point12 = document.getElementById("point12");
var point13 = document.getElementById("point13");
var point14 = document.getElementById("point14");
var point15 = document.getElementById("point15");
var point16 = document.getElementById("point16");
var point17 = document.getElementById("point17");
var point18 = document.getElementById("point18");
var point19 = document.getElementById("point19");
var point20 = document.getElementById("point20");
var point21 = document.getElementById("point21");
var point22 = document.getElementById("point22");
var point23 = document.getElementById("point23");
var point24 = document.getElementById("point24");
var point25 = document.getElementById("point25");
var point26 = document.getElementById("point26");
var point27 = document.getElementById("point27");
var point28 = document.getElementById("point28");
var point29 = document.getElementById("point29");
var point30 = document.getElementById("point30");
var point31 = document.getElementById("point31");
var point32 = document.getElementById("point32");
var point33 = document.getElementById("point33");
var point34 = document.getElementById("point34");
var point35 = document.getElementById("point35");
var point36 = document.getElementById("point36");
var point37 = document.getElementById("point37");
var point38 = document.getElementById("point38");
var point39 = document.getElementById("point39");
var point40 = document.getElementById("point40");
var point41 = document.getElementById("point41");
var point42 = document.getElementById("point42");
var point43 = document.getElementById("point43");
var point44 = document.getElementById("point44");
var point45 = document.getElementById("point45");
var point46 = document.getElementById("point46");
var point47 = document.getElementById("point47");
var point48 = document.getElementById("point48");
var point49 = document.getElementById("point49");
var point50 = document.getElementById("point50");
var point51 = document.getElementById("point51");
var point52 = document.getElementById("point52");
var point53 = document.getElementById("point53");
var point54 = document.getElementById("point54");
var point55 = document.getElementById("point55");
var point56 = document.getElementById("point56");
var point57 = document.getElementById("point57");
var point58 = document.getElementById("point58");
var point59 = document.getElementById("point59");




//var gallery = document.getElementById("gallery");

//var eshop = document.getElementById("eshop");

//var eshop_content = document.getElementById("eshop_content");

//Result
//var result = document.getElementById("result_cms");

//var result = document.getElementById("result_design");

//var result = document.getElementById("soprovozhdenie");

//var result = document.getElementById("content");

//var result = document.getElementById("seo");

//var result = document.getElementById("type_forum");

//var result = document.getElementById("comment");
var result = document.getElementById("point1");
var result = document.getElementById("point2");
var result = document.getElementById("point3");
var result = document.getElementById("point4");
var result = document.getElementById("point5");
var result = document.getElementById("point6");
var result = document.getElementById("point7");
var result = document.getElementById("point8");
var result = document.getElementById("point9");
var result = document.getElementById("point10");
var result = document.getElementById("point11");
var result = document.getElementById("point12");
var result = document.getElementById("point13");
var result = document.getElementById("point14");
var result = document.getElementById("point15");
var result = document.getElementById("point16");
var result = document.getElementById("point17");
var result = document.getElementById("point18");
var result = document.getElementById("point19");
var result = document.getElementById("point20");
var result = document.getElementById("point21");
var result = document.getElementById("point22");
var result = document.getElementById("point23");
var result = document.getElementById("point24");
var result = document.getElementById("point25");
var result = document.getElementById("point26");
var result = document.getElementById("point27");
var result = document.getElementById("point28");
var result = document.getElementById("point29");
var result = document.getElementById("point30");
var result = document.getElementById("point31");
var result = document.getElementById("point32");
var result = document.getElementById("point33");
var result = document.getElementById("point34");
var result = document.getElementById("point35");
var result = document.getElementById("point36");
var result = document.getElementById("point37");
var result = document.getElementById("point38");
var result = document.getElementById("point39");
var result = document.getElementById("point40");
var result = document.getElementById("point41");
var result = document.getElementById("point42");
var result = document.getElementById("point43");
var result = document.getElementById("point44");

var result = document.getElementById("point45");
var result = document.getElementById("point46");
var result = document.getElementById("point47");
var result = document.getElementById("point48");
var result = document.getElementById("point49");
var result = document.getElementById("point50");
var result = document.getElementById("point51");
var result = document.getElementById("point52");
var result = document.getElementById("point53");
var result = document.getElementById("point54");
var result = document.getElementById("point55");
var result = document.getElementById("point56");
var result = document.getElementById("point57");
var result = document.getElementById("point58");
var result = document.getElementById("point59");


//var result = document.getElementById("gallery");

//var result = document.getElementById("eshop");

//var result = document.getElementById("eshop_content");

var result = document.getElementById("result");

//var price_cms = 0;
// var price_design = 0;
//var price_host = 0;
//var price_soprovozhdenie = 0;
//var price_content = 0;
//var price_seo = 0;
// var price_forum = 0;
//var price_comment = 0;

var price_point1 = 0;
var price_point2 = 0;
var price_point3 = 0;
var price_point4 = 0;
var price_point5 = 0;
var price_point6 = 0;
var price_point7 = 0;
var price_point8 = 0;
var price_point9 = 0;
var price_point10 = 0;
var price_point11 = 0;
var price_point12 = 0;
var price_point13 = 0;
var price_point14 = 0;
var price_point15 = 0;
var price_point16 = 0;
var price_point17 = 0;
var price_point18 = 0;
var price_point19 = 0;
var price_point20 = 0;
var price_point21 = 0;
var price_point22 = 0;
var price_point23 = 0;
var price_point24 = 0;
var price_point25 = 0;
var price_point26 = 0;
var price_point27 = 0;
var price_point28 = 0;
var price_point29 = 0;
var price_point30 = 0;
var price_point31 = 0;
var price_point32 = 0;
var price_point33 = 0;
var price_point34 = 0;
var price_point35 = 0;
var price_point36 = 0;
var price_point37 = 0;
var price_point38 = 0;
var price_point39 = 0;
var price_point40 = 0;
var price_point41 = 0;
var price_point42 = 0;
var price_point43 = 0;
var price_point44 = 0;
var price_point45 = 0;
var price_point46 = 0;
var price_point47 = 0;
var price_point48 = 0;
var price_point49 = 0;
var price_point50 = 0;
var price_point51 = 0;
var price_point52 = 0;
var price_point53 = 0;
var price_point54 = 0;
var price_point55 = 0;
var price_point56 = 0;
var price_point57 = 0;
var price_point58 = 0;
var price_point59 = 0;



//var price_gallery = 0;
//var price_eshop = 0;
//var price_eshop_content = 0;
var price = 0;
//price_cms += parseInt(type_cms.options[type_cms.selectedIndex].value);
//price_design += parseInt(type_design.options[type_design.selectedIndex].value);
//price_host += (type_host.checked == true) ? parseInt(type_host.value) : 0;
//price_soprovozhdenie += parseInt(soprovozhdenie.value)*1000;
// price_content += parseInt(content.value)*500;
//price_seo += (seo.checked == true) ? parseInt(seo.value) : 0;
// price_forum += parseInt(type_forum.options[type_forum.selectedIndex].value);
// price_comment += (comment.checked == true) ? parseInt(comment.value) : 0;

price_point1 += (point1.checked == true) ? parseInt(point1.value) : 0;

price_point2 += (point2.checked == true) ? parseInt(point2.value) : 0;
price_point3 += (point3.checked == true) ? parseInt(point3.value) : 0;
price_point4 += (point4.checked == true) ? parseInt(point4.value) : 0;
price_point5 += (point5.checked == true) ? parseInt(point5.value) : 0;
price_point6 += (point6.checked == true) ? parseInt(point6.value) : 0;
price_point7 += (point7.checked == true) ? parseInt(point7.value) : 0;
price_point8 += (point8.checked == true) ? parseInt(point8.value) : 0;
price_point9 += (point9.checked == true) ? parseInt(point9.value) : 0;
price_point10 += (point10.checked == true) ? parseInt(point10.value) : 0;
price_point11 += (point11.checked == true) ? parseInt(point11.value) : 0;
price_point12 += (point12.checked == true) ? parseInt(point12.value) : 0;
price_point13 += (point13.checked == true) ? parseInt(point13.value) : 0;
price_point14 += (point14.checked == true) ? parseInt(point14.value) : 0;
price_point15 += (point15.checked == true) ? parseInt(point15.value) : 0;
price_point16 += (point16.checked == true) ? parseInt(point16.value) : 0;
price_point17 += (point17.checked == true) ? parseInt(point17.value) : 0;
price_point18 += (point18.checked == true) ? parseInt(point18.value) : 0;
price_point19 += (point19.checked == true) ? parseInt(point19.value) : 0;
price_point20 += (point20.checked == true) ? parseInt(point20.value) : 0;
price_point21 += (point21.checked == true) ? parseInt(point21.value) : 0;
price_point22 += (point22.checked == true) ? parseInt(point22.value) : 0;
price_point23 += (point23.checked == true) ? parseInt(point23.value) : 0;
price_point24 += (point24.checked == true) ? parseInt(point24.value) : 0;
price_point25 += (point25.checked == true) ? parseInt(point25.value) : 0;
price_point26 += (point26.checked == true) ? parseInt(point26.value) : 0;
price_point27 += (point27.checked == true) ? parseInt(point27.value) : 0;
price_point28 += (point28.checked == true) ? parseInt(point28.value) : 0;
price_point29 += (point29.checked == true) ? parseInt(point29.value) : 0;
price_point30 += (point30.checked == true) ? parseInt(point30.value) : 0;
price_point31 += (point31.checked == true) ? parseInt(point31.value) : 0;
price_point32 += (point32.checked == true) ? parseInt(point32.value) : 0;
price_point33 += (point33.checked == true) ? parseInt(point33.value) : 0;
price_point34 += (point34.checked == true) ? parseInt(point34.value) : 0;
price_point35 += (point35.checked == true) ? parseInt(point35.value) : 0;
price_point36 += (point36.checked == true) ? parseInt(point36.value) : 0;
price_point37 += (point37.checked == true) ? parseInt(point37.value) : 0;
price_point38 += (point38.checked == true) ? parseInt(point38.value) : 0;
price_point39 += (point39.checked == true) ? parseInt(point39.value) : 0;
price_point40 += (point40.checked == true) ? parseInt(point40.value) : 0;
price_point41 += (point41.checked == true) ? parseInt(point41.value) : 0;
price_point42 += (point42.checked == true) ? parseInt(point42.value) : 0;
price_point43 += (point43.checked == true) ? parseInt(point43.value) : 0;
price_point44 += (point44.checked == true) ? parseInt(point44.value) : 0;
price_point45 += (point45.checked == true) ? parseInt(point45.value) : 0;
price_point46 += (point46.checked == true) ? parseInt(point46.value) : 0;
price_point47 += (point47.checked == true) ? parseInt(point47.value) : 0;
price_point48 += (point48.checked == true) ? parseInt(point48.value) : 0;
price_point49 += (point49.checked == true) ? parseInt(point49.value) : 0;
price_point50 += (point50.checked == true) ? parseInt(point50.value) : 0;
price_point51 += (point51.checked == true) ? parseInt(point51.value) : 0;
price_point52 += (point52.checked == true) ? parseInt(point52.value) : 0;
price_point53 += (point53.checked == true) ? parseInt(point53.value) : 0;
price_point54 += (point54.checked == true) ? parseInt(point54.value) : 0;
price_point55 += (point55.checked == true) ? parseInt(point55.value) : 0;
price_point56 += (point56.checked == true) ? parseInt(point56.value) : 0;
price_point57 += (point57.checked == true) ? parseInt(point57.value) : 0;
price_point58 += (point58.checked == true) ? parseInt(point58.value) : 0;
price_point59 += (point59.checked == true) ? parseInt(point59.value) : 0;










//price_gallery += (gallery.checked == true) ? parseInt(gallery.value) : 0;
//price_eshop += (eshop.checked == true) ? parseInt(eshop.value) : 0;
//price_eshop_content += (eshop_content.checked == true) ? parseInt(eshop_content.value) : 0;
price=price_point1+price_point2+price_point3+price_point4+price_point5+price_point6+price_point7+price_point8+price_point9+price_point10+price_point11+price_point12+price_point13+price_point14+price_point15+price_point16+price_point17+price_point18+price_point19+price_point20+price_point21+price_point22+price_point23+price_point24+price_point25+price_point26+price_point27+price_point28+price_point29+price_point30+price_point31+price_point32+price_point33+price_point34+price_point35+price_point36+price_point37+price_point38+price_point39+price_point40+price_point41+price_point42+price_point43+price_point44+price_point45+price_point46+price_point47+price_point48+price_point49+price_point50+price_point51+price_point52+price_point53+price_point54+price_point55+price_point56+price_point57+price_point58+price_point59;


//result_cms.innerHTML = price_cms;
//result_design.innerHTML = price_design;
//result_host.innerHTML = price_host;
//result_soprovozhdenie.innerHTML = price_soprovozhdenie;
//result_content.innerHTML = price_content;
//result_seo.innerHTML = price_seo;
//result_forum.innerHTML = price_forum;
// result_comment.innerHTML = price_comment;
result_point1.innerHTML = price_point1;
result_point2.innerHTML = price_point2;
result_point3.innerHTML = price_point3;
result_point4.innerHTML = price_point4;
result_point5.innerHTML = price_point5;
result_point6.innerHTML = price_point6;
result_point7.innerHTML = price_point7;
result_point8.innerHTML = price_point8;
result_point9.innerHTML = price_point9;
result_point10.innerHTML = price_point10;
result_point11.innerHTML = price_point11;
result_point12.innerHTML = price_point12;
result_point13.innerHTML = price_point13;
result_point14.innerHTML = price_point14;
result_point15.innerHTML = price_point15;
result_point16.innerHTML = price_point16;
result_point17.innerHTML = price_point17;
result_point18.innerHTML = price_point18;
result_point19.innerHTML = price_point19;
result_point20.innerHTML = price_point20;
result_point21.innerHTML = price_point21;
result_point22.innerHTML = price_point22;
result_point23.innerHTML = price_point23;
result_point24.innerHTML = price_point24;
result_point25.innerHTML = price_point25;
result_point26.innerHTML = price_point26;
result_point27.innerHTML = price_point27;
result_point28.innerHTML = price_point28;
result_point29.innerHTML = price_point29;
result_point30.innerHTML = price_point30;
result_point31.innerHTML = price_point31;
result_point32.innerHTML = price_point32;
result_point33.innerHTML = price_point33;
result_point34.innerHTML = price_point34;
result_point35.innerHTML = price_point35;
result_point36.innerHTML = price_point36;
result_point37.innerHTML = price_point37;
result_point38.innerHTML = price_point38;
result_point39.innerHTML = price_point39;
result_point40.innerHTML = price_point40;
result_point41.innerHTML = price_point41;
result_point42.innerHTML = price_point42;
result_point43.innerHTML = price_point43;
result_point44.innerHTML = price_point44;
result_point45.innerHTML = price_point45;
result_point46.innerHTML = price_point46;
result_point47.innerHTML = price_point47;
result_point48.innerHTML = price_point48;
result_point49.innerHTML = price_point49;
result_point50.innerHTML = price_point50;
result_point51.innerHTML = price_point51;
result_point52.innerHTML = price_point52;
result_point53.innerHTML = price_point53;
result_point54.innerHTML = price_point54;
result_point55.innerHTML = price_point55;
result_point56.innerHTML = price_point56;
result_point57.innerHTML = price_point57;
result_point58.innerHTML = price_point58;
result_point59.innerHTML = price_point59;





result.innerHTML = price;
}
</script>
<table >

<tbody>
<tr>
</tr>
<tr style="border: 1px solid rgb(198, 198, 198); background-color: rgb(238, 238, 238);">
<th style="border: medium none ; padding: 7px; background-color: rgb(238, 238, 238);">�����<br>
</th>
<td style="border: medium none ; text-align: center;"><span style="font-weight: bold;">���� ����</span><br>
</td>
<td style="border: medium none ;"><br>
</td>
<td style="border: medium none ; text-align: center;"><span style="font-weight: bold;">�������� �������</span><br>
</td>
</tr>
<!-- point1// --> <tr>
<td width="150">������� � 1 ( �� 10 ����)<br>
</td>
<td width="250">1 ���������� (��������� �����)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point1" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point1">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point2// --> </tr>
<tr>
<td width="150"><span style="color: rgb(255, 102, 102);">( �����
�� 1 ������ )</span><br>
</td>
<td width="250">2 �������� ( ���.)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point2" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point2">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point3// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">3 �������� ( ����.)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point3" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point3">0</span> <br>
</td>
</tr>
<tr>
<!-- point4// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">4 ������ ����� ( ���.)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point4" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point4">0</span> <br>
</td>
</tr>
<tr>
<!-- 9point5// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">5 ������ ����� ( ����.)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point5" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point5">0</span> <br>
</td>
</tr>
<!-- point6// --> <tr>
<td width="150"><br>
</td>
<td width="250">6 ��������� ������� ( 2-3 �����)<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point6" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point6">0</span> <br>
</td>
</tr>
<!-- point7// --> <tr>
<td width="150"><br>
</td>
<td width="250">7 �������<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="3" id="point7" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point7">0</span> <br>
</td>
</tr>
<!-- point8// --> <tr>
<td width="150"><br>
</td>
<td width="250">8 ˳��������<br>
</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point8" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point8">0</span> <br>
</td>
</tr>
<!-- point9// --> <tr>
<td width="150">������� � 2 ( �� 10 ����) </td>
<td width="250">9 ���������� (��������� �����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point9" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point9">0</span> <br>
</td>
</tr>
<!-- point10// --> <tr>
<td width="150"><span style="color: rgb(255, 102, 102);">( �����
�� 1 ��������� )</span> </td>
<td width="250">10 �������� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point10" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point10">0</span> <br>
</td>
</tr>
<!-- point11// --> <tr>
<td width="150"><br>
</td>
<td width="250">11 �������� ( ����.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point11" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point11">0</span> <br>
</td>
</tr>
<!-- point12// --> <tr>
<td width="150"><br>
</td>
<td width="250">12 ������ ����� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point12" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point12">0</span> <br>
</td>
</tr>
<!-- point13// --> <tr>
<td width="150"><br>
</td>
<td width="250">13 ������ ����� ( ����.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point13" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point13">0</span> <br>
</td>
</tr>
<!-- point14// --> <tr>
<td width="150"><br>
</td>
<td width="250">14 ��������� ������� ( 2-3 �����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point14" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point14">0</span> <br>
</td>
</tr>
<!-- point15// --> <tr>
<td width="150"><br>
</td>
<td width="250">15 ������� </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="3" id="point15" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point15">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point16// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">16 ˳�������� </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point16" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point16">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point17// --> </tr>
<tr>
<td width="150">������� � 3 ( �� 10 ����)<br>
</td>
<td width="250">17 ���������� (��������� �����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point17" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point17">0</span> <br>
</td>
</tr>
<tr>
<!-- point18// --> </tr>
<tr>
<td width="150"><span style="color: rgb(255, 102, 102);">( �����
�� 1 ������ )</span> </td>
<td width="250">18 �������� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point18" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point18">0</span> <br>
</td>
</tr>
<tr>
<!-- 9point19// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">19 �������� ( ����.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point19" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point19">0</span> <br>
</td>
</tr>
<!-- point20// --> <tr>
<td width="150"><br>
</td>
<td width="250">20 ������ ����� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point20" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point20">0</span> <br>
</td>
</tr>
<!-- point21// --> <tr>
<td width="150"><br>
</td>
<td width="250">21 ������ ����� ( ����.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point21" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point21">0</span> <br>
</td>
</tr>
<!-- point22// --> <tr>
<td width="150"><br>
</td>
<td width="250">22 ���������� ������� ( 2-3 ����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point22" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point22">0</span> <br>
</td>
</tr>
<!-- point23// --> <tr>
<td width="150"><br>
</td>
<td width="250">23 ������� </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="3" id="point23" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point23">0</span> <br>
</td>
</tr>
<!-- point24// --> <tr>
<td width="150"><br>
</td>
<td width="250">24 ˳�������� </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point24" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point24">0</span> <br>
</td>
</tr>
<!-- point25// --> <tr>
<td width="150">������� � 4 ( �� 10 ����) </td>
<td width="250">25 ���������� (��������� �����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point25" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point25">0</span> <br>
</td>
</tr>
<!-- point26// --> <tr>
<td width="150"><span style="color: rgb(255, 102, 102);">( �����
�� 24 ������ )</span> </td>
<td width="250">26 �������� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point26" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point26">0</span> <br>
</td>
</tr>
<!-- point27// --> <tr>
<td width="150"><br>
</td>
<td width="250">27 �������� ( ����.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point27" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point27">0</span> <br>
</td>
</tr>
<!-- point28// --> <tr>
<td width="150"><br>
</td>
<td width="250">28 ������ ����� ( ���.) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point28" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point28">0</span> <br>
</td>
</tr>
<!-- point29// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 29 ������ ����� ( ���.)</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point29" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point29">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point30// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250">30 ���������� ������� ( 2-3 ����)</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point30" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point30">0</span> <br>
</td>
</tr>
<tr>
<!-- point31// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250"> 31 �������</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="3" id="point31" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point31">0</span> <br>
</td>
</tr>
<tr>
<!-- 9point32// --> </tr>
<tr>
<td width="150">���. �������� ( �� 22 ����)<br>
</td>
<td width="250"> 32 ˳��������</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="0,5" id="point32" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point32">0</span> <br>
</td>
</tr>
<!-- point33// --> <tr>
<td width="150"><span style="color: rgb(255, 102, 102);">( �����
�� ������ �������� ������)</span><br>
</td>
<td width="250">33 �������� 1 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point33" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point33">0</span> <br>
</td>
</tr>
<!-- point34// --> <tr>
<td width="150"><br>
</td>
<td width="250">34 �������� 2 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point34" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point34">0</span> <br>
</td>
</tr>
<!-- point35// --> <tr>
<td width="150"><br>
</td>
<td width="250">35 �������� 3 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point35" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point35">0</span> <br>
</td>
</tr>
<!-- point36// --> <tr>
<td width="150"><br>
</td>
<td width="250">36 �������� 4 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point36" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point36">0</span> <br>
</td>
</tr>
<!-- point37// --> <tr>
<td width="150"><br>
</td>
<td width="250">37 �������� 5 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point37" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point37">0</span> <br>
</td>
</tr>
<!-- point38// --> <tr>
<td width="150"><br>
</td>
<td width="250">38 �������� 6 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point38" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point38">0</span> <br>
</td>
</tr>
<!-- point39// --> <tr>
<td width="150"><br>
</td>
<td width="250">39 �������� 7 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point39" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point39">0</span> <br>
</td>
</tr>
<!-- point40// --> <tr>
<td width="150"><br>
</td>
<td width="250">40 �������� 8 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point40" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point40">0</span> <br>
</td>
</tr>
<!-- point41// --> <tr>
<td width="150"><br>
</td>
<td width="250">41 �������� 9 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point41" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point41">0</span> <br>
</td>
</tr>
<!-- point42// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 42 �������� 10</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point42" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point42">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point43// --> </tr>
<tr>
<td width="150"> <br>
</td>
<td width="250"> 43 �������� 11</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point43" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point43">0</span> <br>
</td>
</tr>
<!-- ------------------------------------------------------------------------------>
<tr>
<!-- point44// --> </tr>
<tr>
<td width="150">���������� ������ � 1 </td>
<td width="250"> 44 �.�.1 ����.1</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point44" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point44">0</span> <br>
</td>
</tr>
<tr>
<!-- point45// --> </tr>
<tr>
<td width="150"><br>
</td>
<td width="250"> 45 �.�.1 ����.2</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point45" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point45">0</span> <br>
</td>
</tr>
<tr>
<!-- 9point46// --> </tr>
<tr>
<td width="150"> <br>
</td>
<td width="250"> 46 �.�.1 ����.3</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point46" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point46">0</span> <br>
</td>
</tr>
<!-- point47// --> <tr>
<td width="150">���������� ������ � 2 </td>
<td width="250"> 47 �.�.2 ����.1</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point47" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point47">0</span> <br>
</td>
</tr>
<!-- point48// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 48 �.�.2 ����.2</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point48" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point48">0</span> <br>
</td>
</tr>
<!-- point49// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 49 �.�.2 ����.3</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point49" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point49">0</span> <br>
</td>
</tr>
<!-- point50// --> <tr>
<td width="150">���������� ������ � 3 </td>
<td width="250">50 �.�.1 ����.1</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="1" id="point50" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point50">0</span> <br>
</td>
</tr>
<!-- point51// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 51 �.�.3 ����.2</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point51" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point51">0</span> <br>
</td>
</tr>
<!-- point52// --> <tr>
<td width="150"><br>
</td>
<td width="250">52 �.�.3 ����.3 </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point52" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point52">0</span> <br>
</td>
</tr>
<!-- point53// --> <tr>
<td width="150">�������� ( �� 23 ����) </td>
<td width="250">53 ������ �� ��������� ( 7 ����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="7" id="point53" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point53">0</span> <br>
</td>
</tr>
<!-- point54// --> <tr>
<td width="150"><br>
</td>
<td width="250">54 ��������� ( �� 5 ����) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="5" id="point54" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point54">0</span> <br>
</td>
</tr>
<!-- point55// --> <tr>
<td width="150"><br>
</td>
<td width="250">55 ��������� �������� ������ (3) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="3" id="point55" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point55">0</span> <br>
</td>
</tr>
<!-- point56// --> <tr>
<td width="150"><br>
</td>
<td width="250">56 HELP ���� ������ ( �������) (2) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point56" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point56">0</span> <br>
</td>
</tr>
<!-- point57// --> <tr>
<td width="150"><br>
</td>
<td width="250">57 HELP "���������� �����������"(2) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point57" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point57">0</span> <br>
</td>
</tr>
<!-- point58// --> <tr>
<td width="150"><br>
</td>
<td width="250"> 58 HELP "���, �������, �����,&nbsp; ��������
(���.) ( 2)</td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point58" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point58">0</span> <br>
</td>
</tr>
<!-- point59// --> <tr>
<td width="150"><br>
</td>
<td width="250">59 HELP "���, �������, �����, �������� (����.)
(2) </td>
<td style="text-align: center;" width="100"><input onchange="calc()" value="2" id="point59" type="checkbox"></td>
<td style="text-align: center;" width="200"><span id="result_point59">0</span> <br>
</td>
</tr>
<!-- Result --> <tr>
<td class="td_result" width="250">�������:</td>
<td width="150"><br>
</td>
<td width="100"><br>
</td>
<td style="text-align: center;" class="td_result"><span id="result">0</span> <br>
</td>
</tr>
</tbody>
</table>

