<meta http-equiv="content-type" content="text/html; chatset=windows-1251 " />
<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link href="css/reset.css" rel="stylesheet" type="text/css" />

<script type="text/javascript" src="/js/jquery-1.8.2.min.js"></script> 
<script type='text/javascript' src='/js/jquery.validate.js'></script>
<script type='text/javascript' src='/js/scrollup.js'></script>
<script type='text/javascript' src='/js/js1.js'></script>


