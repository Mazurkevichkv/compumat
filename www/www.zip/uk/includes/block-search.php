<div id="block-language"><a href="../uk/index.php"><img src="/images/uk.png"/> </a><a href="../index.php"><img src="/images/ua.gif" /></a></div>

<div id="block-search">
            <form method="GET" action="search.php?q=">
            <span></span>
            <input type="text" id="input-search" name="q" placeholder="Search over lectures" />
            <input type="submit" id="button-search" value="Search"/>
            </form>
            </div>
