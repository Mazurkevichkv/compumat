<div id="block-footer">
<div class="row">
<div id="block-footer1" >

<a  href="index.php">Main</a>
<a href="http://fel.kpi.ua/fel/index.php?lang=uk">Department of Electronics</a>
<a href="korysny-resursi.php">Helpful Resources</a>
<a href="pro-vukladacha.php">About teacher</a>


</div>

<div id="block-footer3" >
<p>With the support of companies </a><a href="http://zyxel.ua/">ZyXEL</a> and<a href="http://qnap.ua/">QNAP</a></p>

</div>
 
</div>
<div id="scrollup"><img alt="Up" src="/images/up.png"></div>
</div>